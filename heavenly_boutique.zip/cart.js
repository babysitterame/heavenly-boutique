let cart = JSON.parse(localStorage.getItem('cart')) || [];
