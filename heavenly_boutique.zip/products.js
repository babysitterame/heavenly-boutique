const products = [
    {id:1, name:"Modest Dress", price:50, img:"https://i.imgur.com/example1.jpg", category:"Dresses"},
    {id:2, name:"Christian Necklace", price:30, img:"https://i.imgur.com/example2.jpg", category:"Accessories"},
];
const productsContainer = document.getElementById("products");
products.forEach(product=>{
    const div=document.createElement("div");
    div.className="product";
    div.innerHTML=`<img src="${product.img}"><h3>${product.name}</h3><p>$${product.price}</p>`;
    productsContainer.appendChild(div);
});
